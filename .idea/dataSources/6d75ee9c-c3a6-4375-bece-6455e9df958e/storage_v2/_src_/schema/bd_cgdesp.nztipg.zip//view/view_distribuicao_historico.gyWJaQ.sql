create view view_distribuicao_historico as
select `h`.`CodigoDistribuicaoHistorico`                    AS `CodigoDistribuicaoHistorico`,
       `h`.`CodigoEmpreendimento`                           AS `CodigoEmpreendimento`,
       concat(`br`.`Br`, '/', `uf`.`Uf`, ' - ', `e`.`Lote`) AS `Empreendimento`,
       `a`.`Nome`                                           AS `NomeAnalista`,
       `h`.`CodigoUsuario`                                  AS `CodigoUsuario`,
       `s`.`Nome`                                           AS `Situacao`,
       date_format(`h`.`Data`, '%d/%m/%Y %H:%i')            AS `Data`
from (((((`bd_cgdesp`.`distibuicao_historico` `h` left join `bd_cgdesp`.`empreendimento` `e` on ((`h`.`CodigoEmpreendimento` = `e`.`CodigoEmpreendimento`))) left join `bd_cgdesp`.`base_uf` `uf` on ((`e`.`CodigoUf` = `uf`.`CodigoUf`))) left join `bd_cgdesp`.`base_rodovia` `br` on ((`e`.`CodigoRodovia` = `br`.`CodigoRodovia`))) left join `bd_cgdesp`.`analista` `a` on ((`h`.`CodigoAnalista` = `a`.`CodigoAnalista`)))
         left join `bd_cgdesp`.`distribuicao_situacao` `s`
                   on ((`h`.`CodigoDistribuicaoSituacao` = `s`.`CodigoDistribuicaoSituacao`)));

