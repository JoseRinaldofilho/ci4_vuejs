create view view_analista as
select `bd_cgdesp`.`analista`.`CodigoAnalista`                                   AS `CodigoAnalista`,
       `bd_cgdesp`.`analista`.`Nome`                                             AS `Nome`,
       `bd_cgdesp`.`analista`.`Matricula`                                        AS `Matricula`,
       `bd_cgdesp`.`analista`.`created_at`                                       AS `created_at`,
       `bd_cgdesp`.`analista`.`Email`                                            AS `Email`,
       `bd_cgdesp`.`analista`.`Senha`                                            AS `Senha`,
       `bd_cgdesp`.`analista`.`TokenAtivacao`                                    AS `TokenAtivacao`,
       `bd_cgdesp`.`analista`.`Ativo`                                            AS `Ativo`,
       (select group_concat(`d`.`Nome` separator '<br>')
        from (`bd_cgdesp`.`analista_disciplina` `ad`
                 left join `bd_cgdesp`.`disciplina` `d` on ((`ad`.`CodigoDisciplina` = `d`.`CodigoDisciplina`)))
        where (`ad`.`CodigoAnalista` = `bd_cgdesp`.`analista`.`CodigoAnalista`)) AS `Especialidades`,
       date_format((select (max(`bd_cgdesp`.`agenda`.`Fim`) + interval 1 day) AS `Fim`
                    from `bd_cgdesp`.`agenda`
                    where (`bd_cgdesp`.`agenda`.`CodigoAnalista` = `bd_cgdesp`.`analista`.`CodigoAnalista`)
                    limit 1), '%d/%m/%Y')                                        AS `ProximaDataLivre`
from `bd_cgdesp`.`analista`;

