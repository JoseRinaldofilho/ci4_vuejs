create view view_agenda as
select `bd_cgdesp`.`agenda`.`CodigoAgenda`                              AS `CodigoAgenda`,
       concat(`bd_cgdesp`.`base_rodovia`.`Br`, '/', `bd_cgdesp`.`base_uf`.`Uf`, ' - ',
              `bd_cgdesp`.`empreendimento`.`Lote`)                      AS `Empreendimento`,
       date_format(`bd_cgdesp`.`agenda`.`Inicio`, '%d/%m/%Y')           AS `Inicio`,
       date_format(`bd_cgdesp`.`agenda`.`Fim`, '%d/%m/%Y')              AS `Fim`,
       `bd_cgdesp`.`disciplina`.`Nome`                                  AS `NomeDisciplina`,
       `bd_cgdesp`.`distribuicao_situacao`.`Nome`                       AS `Situacao`,
       `bd_cgdesp`.`distribuicao_situacao`.`CodigoDistribuicaoSituacao` AS `CodigoDistribuicaoSituacao`,
       `bd_cgdesp`.`analista`.`Nome`                                    AS `NomeAnalista`,
       `bd_cgdesp`.`analista`.`CodigoAnalista`                          AS `CodigoAnalista`,
       `bd_cgdesp`.`agenda_tipo`.`Nome`                                 AS `TipoAgenda`,
       `bd_cgdesp`.`agenda`.`CodigoAgendaTipo`                          AS `CodigoAgendaTipo`
from (((((((`bd_cgdesp`.`agenda` left join `bd_cgdesp`.`empreendimento` on ((
        `bd_cgdesp`.`agenda`.`CodigoEmpreendimento` =
        `bd_cgdesp`.`empreendimento`.`CodigoEmpreendimento`))) left join `bd_cgdesp`.`distribuicao_situacao` on ((
        `bd_cgdesp`.`empreendimento`.`CodigoDistribuicaoSituacao` =
        `bd_cgdesp`.`distribuicao_situacao`.`CodigoDistribuicaoSituacao`))) left join `bd_cgdesp`.`base_uf` on ((
        `bd_cgdesp`.`empreendimento`.`CodigoUf` =
        `bd_cgdesp`.`base_uf`.`CodigoUf`))) left join `bd_cgdesp`.`base_rodovia` on ((
        `bd_cgdesp`.`empreendimento`.`CodigoRodovia` =
        `bd_cgdesp`.`base_rodovia`.`CodigoRodovia`))) left join `bd_cgdesp`.`disciplina` on ((
        `bd_cgdesp`.`empreendimento`.`CodigoDisciplina` =
        `bd_cgdesp`.`disciplina`.`CodigoDisciplina`))) left join `bd_cgdesp`.`analista` on ((
        `bd_cgdesp`.`agenda`.`CodigoAnalista` = `bd_cgdesp`.`analista`.`CodigoAnalista`)))
         left join `bd_cgdesp`.`agenda_tipo`
                   on ((`bd_cgdesp`.`agenda`.`CodigoAgendaTipo` = `bd_cgdesp`.`agenda_tipo`.`CodigoAgendaTipo`)))
order by `bd_cgdesp`.`agenda`.`Inicio`;

