create view view_distribuicao as
select `bd_cgdesp`.`empreendimento`.`CodigoEmpreendimento`                 AS `CodigoEmpreendimento`,
       `bd_cgdesp`.`empreendimento`.`CodigoDisciplina`                     AS `CodigoDisciplina`,
       `bd_cgdesp`.`empreendimento`.`Lote`                                 AS `Lote`,
       `bd_cgdesp`.`empreendimento`.`CodigoDistribuicaoSituacao`           AS `CodigoDistribuicaoSituacao`,
       date_format(`bd_cgdesp`.`empreendimento`.`DataEntrega`, '%d/%m/%y') AS `DataEntrega`,
       `bd_cgdesp`.`base_uf`.`Uf`                                          AS `Uf`,
       `bd_cgdesp`.`base_rodovia`.`Rodovia`                                AS `Br`,
       `bd_cgdesp`.`distribuicao_situacao`.`Nome`                          AS `Situacao`,
       `bd_cgdesp`.`disciplina`.`Nome`                                     AS `NomeDisciplina`,
       (select `bd_cgdesp`.`analista`.`Nome`
        from (`bd_cgdesp`.`agenda`
                 left join `bd_cgdesp`.`analista`
                           on ((`bd_cgdesp`.`analista`.`CodigoAnalista` = `bd_cgdesp`.`agenda`.`CodigoAnalista`)))
        where (`bd_cgdesp`.`agenda`.`CodigoEmpreendimento` = `bd_cgdesp`.`empreendimento`.`CodigoEmpreendimento`)
        order by `bd_cgdesp`.`agenda`.`CodigoEmpreendimento` desc
        limit 1)                                                           AS `NomeAnalista`
from ((((`bd_cgdesp`.`empreendimento` left join `bd_cgdesp`.`base_uf` on ((`bd_cgdesp`.`empreendimento`.`CodigoUf` =
                                                                           `bd_cgdesp`.`base_uf`.`CodigoUf`))) left join `bd_cgdesp`.`base_rodovia` on ((
        `bd_cgdesp`.`empreendimento`.`CodigoRodovia` =
        `bd_cgdesp`.`base_rodovia`.`CodigoRodovia`))) left join `bd_cgdesp`.`disciplina` on ((
        `bd_cgdesp`.`empreendimento`.`CodigoDisciplina` = `bd_cgdesp`.`disciplina`.`CodigoDisciplina`)))
         left join `bd_cgdesp`.`distribuicao_situacao` on ((`bd_cgdesp`.`empreendimento`.`CodigoDistribuicaoSituacao` =
                                                            `bd_cgdesp`.`distribuicao_situacao`.`CodigoDistribuicaoSituacao`)));

